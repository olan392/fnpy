import sys
import threading as tr
import time
import os
import json
path = input("fnpy path: ")
sys.path.append(f"{path}/assets/data/chart")
import normal
timer = 0.0
R = True
lock = tr.Lock()
dataPath = f"{path}/assets/data/data.json"
if not os.path.exists(dataPath):
    raise FileNotFoundError("data.json is not a file or directory")

with open(dataPath, "r") as f:
    mod = json.load(f)

print("name:", mod["modname"])
print("desc:", mod["desc"])
scriptPath = f"{path}/assets/data/scripts/script.py"
if not os.path.exists(scriptPath):
    s = False
else:
    s = True
sys.path.append(f"{path}/assets/data/scripts")
if s:
    import script
else:
    pass

settings = f"{path}/assets/data/config/settings.json"
if os.path.exists(settings):
    with open(settings, "r") as f:
        cfg = json.load(f)
    cfgE = True
else:
    cfgE = False

def tm():
    global timer
    while R:
        time.sleep(0.1)
        with lock:
            timer += 0.1
    return
tim = tr.Thread(target=tm)
tim.start()
if s and hasattr(script, "onStart"):
    script.onStart()

for note in normal.chart:
    if "customnotes" in cfg and not cfg["customnotes"] and note not in ["l", "d", "u", "r"] and cfgE or not cfgE:
        raise SyntaxError(f"{note} is a custom not but not allowed")
    print("your note:", note)
    R = True
    arrow = input("note> ")
    pf = 0.6
    if cfgE and "perfecttiming" in cfg:
        pf = cfg["perfecttiming"]
    if R == False:
        R = True
        timer = 0.0
    if arrow == note:
        if timer >= 2.5:
            print("miss!")
            R = False
        elif timer >= 1.7:
            print("bad!")
            R = False
        elif timer >= 1.2:
            print("good!")
            R = False
        elif timer >= 0.6:
            print("perfect!")
            R = False
    else:
        print("miss!")
    R = False
R = False
if s and hasattr(script, "onEnd"):
    script.onEnd()
print(f"you beat {normal.op}")
chart = ["l", "r", "u", "d", "r", "u", "d", "r"]
op = "gf"